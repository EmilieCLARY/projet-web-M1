import { UserModel, PlainUserModel } from 'library-api/src/models';

export type PlainUserUseCasesOutput = PlainUserModel;
export type UserUseCasesOutput = UserModel;
