export type PlainBookModel = {
  author: any;
  id: string;
  name: string;
};
